package com.example.x.bolusopas;

/**
 * Created by rusty on 25.7.2016.
 */
public class GV {
    public static final String PREFS_NAME = "bolusSettings";
    public static final int BADVALUE = -606,
            LANGUAGE_ENGLISH = 0,
            LANGUAGE_FINNISH = 1,
            LANGUAGE_SWEDISH = 2,
            INSULIN_EFFECT_DELAY_MINUTES = 15;
}
