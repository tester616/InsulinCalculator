package com.example.x.bolusopas;


import android.widget.Button;

public class HistoryItem {

    private Result result;

    public HistoryItem(Result result) {
        this.result = result;
    }

    public Result getResult() {
        return result;
    }

    //toString()?
}
